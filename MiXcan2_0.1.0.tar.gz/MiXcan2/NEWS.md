# MiXcan2 0.1.0

* Initial CRAN submission.
